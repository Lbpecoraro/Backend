export default {
    mongodb: {
        mongo: "mongodb+srv://matias:351426351@cluster0.6lyvpyc.mongodb.net/?retryWrites=true&w=majority",
        db: "ecommerce",
        collectionMessage: "mensajes"
    }
}